

typedef struct _memitem {
	uint8_t *buf;
	uint32_t used;
	long adddata;
	struct _memitem *next;
} memitem;

class crtlockqueue
{
public:
	crtlockqueue();
	virtual ~crtlockqueue();
	int put(void *buf);
	void flush();
	void abort();
	void* get(int block);
	int isaborted();
protected:
	volatile memitem *first_pkt, *last_pkt;
	volatile int nb_packets;
	volatile int abort_request;
	crtmutex mutex;
	crtcond cond;
};

class crtlockdataqueue {
public:
	crtlockdataqueue();
	virtual ~crtlockdataqueue();
	void clear();
	void setbufsize(uint32_t bs);
	uint32_t getbufsize();
	long touchheaderblock();
	memitem *getblock();
	memitem *getornewblock();
	void putblock(memitem *t);
	inline int32_t getcount(){return datacount;}
protected:
	crtmutex mtx;
	queue<memitem *> q;
	uint32_t bufsize;
	volatile int32_t datacount;
};
class crtdataqueue {
public:
	crtdataqueue();
	virtual ~crtdataqueue();
	void clear();
	void setbufsize(uint32_t bs);
	uint32_t getbufsize();
	long touchheaderblock();
	memitem *getblock();
	memitem *getornewblock();
	void putblock(memitem *t);
	inline int32_t getcount(){return datacount;}
protected:
	uint32_t bufsize;
	memitem *head;
	memitem *end;
	volatile int32_t datacount;
};
class crtqueue {
public:
	crtqueue();
	virtual ~crtqueue();
	void clear();
	void setbufsize(uint32_t bs);
	uint32_t getbufsize();
	long touchheaderdata();
	memitem *newblock();
	void releaseblock(memitem *t);
	memitem *header();
	void putback(memitem *t);
	uint32_t getqueuesize();
protected:
	crtlockdataqueue m_queue;
	crtlockdataqueue m_buffer;
};


crtlockqueue::crtlockqueue()
{
	first_pkt=last_pkt=NULL;
	nb_packets=abort_request=0;
}
crtlockqueue::~crtlockqueue()
{
	flush();
}
int crtlockqueue::put(void *pkt)
{
	memitem *pkt1;
	pkt1 = new memitem;
	if (!pkt1) return -1;
	pkt1->buf = (uint8_t *)pkt;
	pkt1->next = NULL;
	mutex.lock();
	if (!last_pkt) first_pkt = pkt1;
	else last_pkt->next = pkt1;
	last_pkt = pkt1;
	nb_packets++;
	cond.signal();
	mutex.unlock();
	return 0;
}
void crtlockqueue::flush()
{
	memitem *pkt, *pkt1;
	mutex.lock();
	for (pkt = (memitem *)first_pkt; pkt != NULL; pkt = pkt1) {
		pkt1 = pkt->next;
		delete [] pkt->buf;
		delete pkt;
	}
	last_pkt = NULL;
	first_pkt = NULL;
	nb_packets = 0;
	mutex.unlock();
}
void crtlockqueue::abort()
{
	mutex.lock();
	abort_request = 1;
	cond.signal();
	mutex.unlock();
}
void* crtlockqueue::get(int block)
{
	memitem *pkt1;
	mutex.lock();
	for (;;) {
		if (abort_request) break;
		pkt1 = (memitem *)first_pkt;
		if (pkt1) {
			first_pkt = pkt1->next;
			if (!first_pkt) last_pkt = NULL;
			nb_packets--;
			void *buf = pkt1->buf;
			delete pkt1;
			mutex.unlock();
			return buf;
		} else if (!block) break;
		else cond.wait(&mutex);
	}
	mutex.unlock();
	return NULL;
}
int crtlockqueue::isaborted(){return abort_request;}

crtlockdataqueue::crtlockdataqueue() {
	bufsize = 0;
	datacount = 0;
}
crtlockdataqueue::~crtlockdataqueue() {
	clear();
}
void crtlockdataqueue::clear() {
	mtx.lock();
	memitem *m;
	while (!q.empty()) {
		m = q.front();
		delete[] m->buf;
		delete m;
		q.pop();
	}
	datacount = 0;
	mtx.unlock();
}
void crtlockdataqueue::setbufsize(uint32_t bs) {
	bufsize = bs;
}
inline uint32_t crtlockdataqueue::getbufsize() {
	return bufsize;
}
long crtlockdataqueue::touchheaderblock()
{
	long ret=0;
	mtx.lock();
	if (!q.empty()) ret=q.front()->adddata;
	mtx.unlock();
	return ret;
}
memitem *crtlockdataqueue::getblock() {
	memitem *m = NULL;
	mtx.lock();
	if (!q.empty()) {
		m = q.front();
		q.pop();
		datacount--;
	}
	mtx.unlock();
	return m;
}
memitem *crtlockdataqueue::getornewblock() {
	memitem *t = getblock();
	if (!t) {
		if (bufsize == 0)
			return NULL;
		t = new memitem;
		t->buf = new uint8_t[bufsize];
		mtx.lock();
		datacount--;
		mtx.unlock();
	}
	return t;
}
void crtlockdataqueue::putblock(memitem *t) {
	mtx.lock();
	q.push(t);
	datacount++;
	mtx.unlock();
}
crtdataqueue::crtdataqueue() {
	head = end = NULL;
	bufsize = 0;
	datacount = 0;
}
crtdataqueue::~crtdataqueue() {
	clear();
}
void crtdataqueue::clear() {
	memitem *p = head;
	while (p) {
		memitem *t = p;
		p = p->next;
		delete[] t->buf;
		delete t;
	}
	datacount = 0;
}
void crtdataqueue::setbufsize(uint32_t bs) {
	bufsize = bs;
}
inline uint32_t crtdataqueue::getbufsize() {
	return bufsize;
}
long crtdataqueue::touchheaderblock()
{
	long ret=0;
	if (head && head->next)
		ret = head->adddata;
	return ret;
}
//getblock �� releaseblock֮���̰߳�ȫ��getblock���?�̰߳�ȫ
memitem *crtdataqueue::getblock() {
	//֤��end�϶���head���棬��end�ı�ʱ����Ӱ��head
	if (head && head->next) {
		memitem *t = head;
		head = head->next;
		datacount--;
		return t;
	}
	return NULL;
}
memitem *crtdataqueue::getornewblock() {
	memitem *t = getblock();
	if (!t) {
		if (bufsize == 0)
			return NULL;
		t = new memitem;
		t->buf = new uint8_t[bufsize];
		datacount--;
	}
	return t;
}
void crtdataqueue::putblock(memitem *t) {
	t->next = NULL;
	if (end)
		end->next = t;
	end = t;
	if (!head)
		head = end;
	datacount++;
}
crtqueue::crtqueue(){}
crtqueue::~crtqueue(){clear();}
void crtqueue::clear(){m_queue.clear();m_buffer.clear();}
void crtqueue::setbufsize(uint32_t bs){m_buffer.setbufsize(bs);m_queue.setbufsize(bs);}
uint32_t crtqueue::getbufsize(){return m_buffer.getbufsize();}
long crtqueue::touchheaderdata(){return m_queue.touchheaderblock();}
memitem *crtqueue::newblock(){return m_buffer.getornewblock();}
void crtqueue::releaseblock(memitem *t){return m_buffer.putblock(t);}
memitem *crtqueue::header(){return m_queue.getblock();}
void crtqueue::putback(memitem *t){return m_queue.putblock(t);}
uint32_t crtqueue::getqueuesize(){return (uint32_t)m_queue.getcount();}
