#include "MyIni.h"
#include "CFile.h"

#if	defined(_DEBUG) && defined(WIN32)
#define new DEBUG_NEW
#endif

static unsigned int s2h(CString str){return _tcstol(str,'\0',16);}

CMyIni::CMyIni()
{
	m_bUseEncMode=FALSE;
	m_bCrc=FALSE;
#if !defined(_WIN32) || defined(_WIN32_WCE)
	m_objcache=FALSE;
	m_obj=new keyvalueobjs;
#endif
}

CMyIni::CMyIni(CString sPath)
{
	m_bUseEncMode=FALSE;
	m_bCrc=FALSE;
#if !defined(_WIN32) || defined(_WIN32_WCE)
	m_objcache=FALSE;
	m_obj=new keyvalueobjs;
#endif
	Init(sPath);
}

CMyIni::~CMyIni()
{
#if !defined(_WIN32) || defined(_WIN32_WCE)
	delete m_obj;
#endif
}

BOOL CMyIni::EnumAllStruct(CStringArray *arKey)
{
	if (!arKey) return FALSE;
	if (!IniEnumAllStruct(m_sPath,arKey)) return FALSE;
	if (m_bUseEncMode)
	{
		for(int i=0;i<arKey->GetSize();i++)
		{
			CString str=arKey->GetAt(i);
			arKey->SetAt(i,DecBuffer(str));
		}
	}
	return TRUE;
}

BOOL CMyIni::EnumStruct(const CString sKey,CStringArray *arKey,CStringArray *arValue)
{
	if (!arKey || !arValue) return FALSE;
	if (!IniEnumStruct(m_sPath,EncBuffer(sKey),arKey,arValue)) return FALSE;
	if (m_bUseEncMode)
	{
		for(int i=0;i<arKey->GetSize();i++)
		{
			CString str=arKey->GetAt(i);
			arKey->SetAt(i,DecBuffer(str));
			str=arValue->GetAt(i);
			arValue->SetAt(i,DecBuffer(str));
		}
	}
	return TRUE;
}

CString CMyIni::EncBuffer(CString sBuf)
{
	if (m_bUseEncMode)
	{
		CString ret;
		int idx=0;
		int len=sBuf.GetLength()*sizeof(TCHAR);
		unsigned char *buf=(unsigned char *)sBuf.GetBuffer();
		for(int i=0;i<len;i++)
			ret.AppendFormat(_T("%02x"),(unsigned char)(*(buf+i))^PassSeed[(idx++)%8]);
		if (m_bCrc)
			ret.AppendFormat(_T("%04x"),CCrc::Crc16(buf,len));
		sBuf.ReleaseBuffer();
		return ret;
	}
	return sBuf;
}

CString CMyIni::DecBuffer(CString sBuf)
{
	if (m_bUseEncMode)
	{
		int idx=0;
		CString ret;
		int len=sBuf.GetLength();
		if (m_bCrc) len-=4;
		if (len<0) return _T("");
		unsigned char *buf=(unsigned char *)ret.GetBuffer(sBuf.GetLength()+2);
		for(int i=0;i<len;i+=2)
		{
			unsigned char ch=s2h(sBuf.Mid(i).Left(2));
			*(buf+idx++)=ch^PassSeed[(idx)%8];
		}
		if (m_bCrc)
		{
			U16 ch=s2h(sBuf.Mid(len).Left(4));
			if (CCrc::Crc16(buf,idx)!=ch) return _T("");
		}
		*(buf+idx++)='\0';
		*(buf+idx++)='\0';
		ret.ReleaseBuffer();
		return ret;
	}
	return sBuf;
}

#if defined(_WIN32) && !defined(_WIN32_WCE)

#define CUTSIZE		4000
#define ADDTAG		_T("ADDTAG")

CString CMyIni::IniGetString(CString sFile,CString sApp,CString sKey,CString sDefValue)
{
	CString buffer;
	int InitSize=4096;
	while(GetPrivateProfileString(sApp,sKey,sDefValue,buffer.GetBuffer(InitSize),InitSize,sFile)==InitSize)
	{
		//���������ܲ������Ӵ󻺳�������
		buffer.ReleaseBuffer();
		InitSize*=2;
	}
	buffer.ReleaseBuffer();
	if (buffer.GetLength()==CUTSIZE)
		buffer+=IniGetString(sFile,sApp,sKey+ADDTAG,_T(""));
	return buffer;
}

BOOL CMyIni::IniWriteString(CString sFile,CString sApp,CString sKey,CString sValue)
{
	if (sValue.GetLength()>CUTSIZE)
	{
		if (!IniWriteString(sFile,sApp,sKey+ADDTAG,sValue.Mid(CUTSIZE))) return FALSE;
		sValue=sValue.Left(CUTSIZE);
	}
	return WritePrivateProfileString(sApp,sKey,sValue,sFile);
}

BOOL CMyIni::IniDeleteString(CString sFile,CString sApp,CString sKey){return WritePrivateProfileString(sApp,sKey,NULL,sFile);}

BOOL CMyIni::IniGetBin(CString sFile,CString sApp,CString sKey,void *pBuffer,UINT uSize){return GetPrivateProfileStruct(sApp,sKey,pBuffer,uSize,sFile);}

BOOL CMyIni::IniWriteBin(CString sFile,CString sApp,CString sKey,void *pBuffer,UINT uSize){return WritePrivateProfileStruct(sApp,sKey,pBuffer,uSize,sFile);}

BOOL CMyIni::IniEnumAllStruct(CString sFile,CStringArray *arKey)
{
	if (!arKey) return FALSE;
	arKey->RemoveAll();
	TCHAR buf[4096];
	TCHAR *buffer=buf;
	DWORD rcnt=GetPrivateProfileSectionNames(buf,sizeof(buf),sFile);
	if (rcnt==0) return FALSE;
	CString tmp;
	while(*buffer!='\0')
	{
		tmp=buffer;
		buffer+=tmp.GetLength()+1;
		tmp.Trim();
		if (!tmp.IsEmpty())
			arKey->Add(tmp);
	}
	return TRUE;
}

BOOL CMyIni::IniEnumStruct(CString sFile,const CString sKey,CStringArray *arKey,CStringArray *arValue)
{
	if (!arKey || !arValue) return FALSE;
	arKey->RemoveAll();
	arValue->RemoveAll();
	const int maxlen=64*1024;
	TCHAR *buffer=new TCHAR[maxlen+2];
	TCHAR *sbuffer=buffer;
	if (!buffer) return FALSE;
	//microsoft bug Q198906
	GetPrivateProfileString(NULL,NULL,NULL,buffer,maxlen,sFile);
	DWORD rcnt=GetPrivateProfileSection(sKey,buffer,maxlen,sFile);
	if (rcnt==0)
	{
		delete [] sbuffer;
		return FALSE;
	}
	CString tmp;
	while(*buffer!='\0')
	{
		tmp=buffer;
		buffer+=tmp.GetLength()+1;
		if (!tmp.IsEmpty())
		{
			int pos=tmp.Find(_T("="),0);
			if (pos!=-1)
			{
				arKey->Add(tmp.Left(pos).Trim());
				arValue->Add(tmp.Mid(pos+1).Trim());
			}
		}
	}
	delete [] sbuffer;
	return TRUE;
}

#else

BOOL WriteWholeFile(LPCTSTR sFile,const void *buf,UINT len)
{
	FILE *fp=_tfopen(sFile,_T("wb"));
	if (!fp) return FALSE;
	fwrite(buf,1,len,fp);
	fclose(fp);
	return TRUE;
}

void *ReadWholeFile(LPCTSTR sFile,UINT *len)
{
	FILE *fp=_tfopen(sFile,_T("rb"));
	if (!fp) return FALSE;
	fseek(fp,0,SEEK_END);
	*len=ftell(fp);
	void *buf=new char[*len];
	fseek(fp,0,SEEK_SET);
	fread(buf,1,*len,fp);
	fclose(fp);
	return buf;
}

void FreeBuf(void *buf)
{
	delete [] (char *)buf;
}

BOOL CMyIni::SaveIniObject(CString sFile)
{
	if (m_nLastCacheFile!=sFile) return FALSE;
	keyvalueobjs::iterator it=m_obj->begin();
	CString ret;
	for(;it!=m_obj->end();it++)
	{
		keyvalueobj::iterator it1=it->second.begin();
		ret.AppendFormat(_T("[%s]\n"),(LPCTSTR)it->first);
		for(;it1!=it->second.end();it1++)
			ret.AppendFormat(_T("%s=%s\n"),(LPCTSTR)it1->first,(LPCTSTR)it1->second);
		ret+=_T("\n");
	}
	if (ret.IsEmpty())
	{
		DeleteFile(sFile);
		return TRUE;
	}
	char *tmp=CCharset::t2a(ret);
	BOOL bret=FALSE;
	if (tmp)
	{
		bret=WriteWholeFile(sFile,tmp,(UINT)strlen(tmp));
		CCharset::free(tmp);
	}
	return bret;
}

BOOL CMyIni::ParseIniObject(CString sFile)
{
	if (m_objcache && m_nLastCacheFile==sFile) return TRUE;
	m_obj->clear();
	UINT len;
	void *buf=ReadWholeFile(sFile,&len);
	if (!buf || len==0) return FALSE;
	CString allbuf=CCharset::a2t((char *)buf,len);
	FreeBuf(buf);
	//0 for search key
	//1 for search content
	int type=0;
	CString ret;
	while(!allbuf.IsEmpty())
	{
		if (type==0)
		{
			ret.Empty();
			int pos=allbuf.Find(_T("["));
			if (pos==-1) break;
			int pos2=allbuf.Find(_T("]"),pos);
			if (pos2==-1) break;
			ret=allbuf.Left(pos2).Mid(pos+1);
			ret.Trim();
			allbuf=allbuf.Mid(pos2+1);
			if (!ret.IsEmpty()) type=1;
		}
		if (type==1)
		{
			int end=allbuf.Find(_T("["),0);
			if (end==-1) end=allbuf.GetLength();
 			CString str=allbuf.Left(end);
			str.Replace(_T("\r\n"),_T("\n"));
			str.Replace(_T("\r"),_T("\n"));
			CStringToken t(str,_T("\n"));
			CString k,v;
			while(t.IsMoreTokens())
			{
				str=t.GetNextToken();
				int pos=str.Find(_T("="));
				if (pos!=-1)
				{
					k=str.Left(pos);
					k.Trim();
					v=str.Mid(pos+1);
					v.Trim();
					if (!k.IsEmpty())
					{
						keyvalueobjs::iterator it=m_obj->find(ret);
						if (it==m_obj->end())
						{
							keyvalueobj map;
							map[k]=v;
							m_obj->insert(keyvalueobjs::value_type(ret,map));
						}
						else
						{
							(it->second)[k]=v;
						}
					}
				}
			}
			allbuf=allbuf.Mid(end);
			if (allbuf.IsEmpty()) break;
			type=0;
		}
	}
	m_objcache=TRUE;
	m_nLastCacheFile=sFile;
	return TRUE;
}

CString CMyIni::IniGetString(CString sFile,CString sApp,CString sKey,CString sDefValue)
{
	CMySingleLock l(&m_objmtx);
	ParseIniObject(sFile);
	keyvalueobjs::iterator it=m_obj->find(sApp);
	if (it!=m_obj->end())
	{
		keyvalueobj::iterator it1=it->second.find(sKey);
		if (it1!=it->second.end())
		{
			return it1->second;
		}
	}
	return sDefValue;
}

BOOL CMyIni::IniWriteString(CString sFile,CString sApp,CString sKey,CString sValue)
{
	CMySingleLock l(&m_objmtx);
	ParseIniObject(sFile);
	BOOL bFound=FALSE;
	keyvalueobjs::iterator it=m_obj->find(sApp);
	if (it==m_obj->end())
	{
		keyvalueobj map;
		map[sKey]=sValue;
		m_obj->insert(keyvalueobjs::value_type(sApp,map));
	}
	else
	{
		it->second[sKey]=sValue;
	}
	return SaveIniObject(sFile);
}

BOOL CMyIni::IniDeleteString(CString sFile,CString sApp,CString sKey)
{
	CMySingleLock l(&m_objmtx);
	ParseIniObject(sFile);
	BOOL bFound=FALSE;
	keyvalueobjs::iterator it=m_obj->find(sApp);
	if (it==m_obj->end()) return TRUE;
	it->second.erase(sKey);
	return SaveIniObject(sFile);
}

BOOL CMyIni::IniGetBin(CString sFile,CString sApp,CString sKey,void *pBuffer,UINT uSize)
{
	CString ret=IniGetString(sFile,sApp,sKey);
	if (ret.IsEmpty()) return FALSE;
	if (ret.GetLength()!=(uSize+1)*2 || ret.GetLength()<=2) return FALSE;
	U8 sum=0;
	UINT len=sizeof(U8);
	if (!CStringConv::HexStringToBin(ret.Mid(ret.GetLength()-2),&sum,&len)) return FALSE;
	len=uSize;
	if (!CStringConv::HexStringToBin(ret.Left(ret.GetLength()-2),pBuffer,&len)) return FALSE;
	if (len!=uSize) return FALSE;
	U8 sum1=0;
	for(UINT i=0;i<uSize;i++)
		sum1+=*((U8 *)pBuffer+i);
	return (sum1==sum);
}

BOOL CMyIni::IniWriteBin(CString sFile,CString sApp,CString sKey,void *pBuffer,UINT uSize)
{
	if (!pBuffer || uSize==0) return FALSE;
	U8 *pbuf=(U8 *)pBuffer;
	CString sValue;
	U8 sum=0;
	for(UINT i=0;i<uSize;i++)
	{
		sValue.AppendFormat(_T("%02X"),*(pbuf+i));
		sum+=*(pbuf+i);
	}
	sValue.AppendFormat(_T("%02X"),sum);
	return IniWriteString(sFile,sApp,sKey,sValue);
}

BOOL CMyIni::IniEnumAllStruct(CString sFile,CStringArray *arKey)
{
	if (!arKey) return FALSE;
	CMySingleLock l(&m_objmtx);
	ParseIniObject(sFile);
	keyvalueobjs::iterator it=m_obj->begin();
	for(;it!=m_obj->end();it++)
		arKey->Add(it->first);
	return TRUE;
}

BOOL CMyIni::IniEnumStruct(CString sFile,const CString sKey,CStringArray *arKey,CStringArray *arValue)
{
	if (!arKey || !arValue) return FALSE;
	CMySingleLock l(&m_objmtx);
	ParseIniObject(sFile);
	keyvalueobjs::iterator it=m_obj->find(sKey);
	if (it!=m_obj->end())
	{
		keyvalueobj::iterator it1=it->second.begin();
		for(;it1!=it->second.end();it1++)
		{
			arKey->Add(it1->first);
			arValue->Add(it1->second);
		}
	}
	return TRUE;
}
#endif
