/*
 * @file: unistd.h
 * a mini unistd.h for MS VC++ compiler
 * Created by next@ppnext.com
 * 2008-10-30 19:29:49
 */
 
 #ifndef _UNISTD_H

 #define _UNISTD_H
 #include <IO.H>

 #include <PROCESS.H>

 #endif /* _UNISTD_H */
         