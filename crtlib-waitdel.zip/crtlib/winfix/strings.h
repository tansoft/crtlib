/*
 * This file is provided because non ANSI fuctions are described in string.h 
 * that belong in strings.h.  These functions are provided for in the OLDNAME
 * libraries.
 * Author: next@ppnext.com
*/
#ifndef STRINGS_H_MSVC
#define STRINGS_H_MSVC 1
#include <string.h>
#endif
