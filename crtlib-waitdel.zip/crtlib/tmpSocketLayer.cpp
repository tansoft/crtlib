#include "SocketLayer.h"

#if	defined(_DEBUG) && defined(WIN32)
#define new DEBUG_NEW
#endif

BOOL IRawSocketBufferedEventHandler::ReceiveHandler(ISocketLayer *cls,RAWSOCKET sock,const void *bufdata,int buflen,struct sockaddr_in *paddr,void *adddata)
{
#ifdef _DEBUGORGDATA
	FILE *fp=fopen("org.data","ab");
/*	fwrite("\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc"),12,1,fp);
	DWORD dw=GetTickCount();
	fwrite(&dw,4,1,fp);*/
	fwrite(bufdata,buflen,1,fp);
	fclose(fp);
#endif
	if (m_buf.GetBuffedSize((int)sock)==0)
	{
		//�ȳ���ֱ�ӷ���
		while(buflen>0)
		{
			UINT readylen=IsBufferReady(cls,sock,bufdata,buflen,paddr,adddata);
			if (readylen>0)
				BufferedReceiveHandler(cls,sock,bufdata,readylen,paddr,adddata);
			else
				break;
			bufdata=((const char *)bufdata)+readylen;
			buflen-=readylen;
		}
		if (buflen>0)
		{
			if (!m_buf.AddBuf((int)sock,bufdata,buflen))
			{
				ASSERT(FALSE);
				return FALSE;
			}
		}
		return TRUE;
	}
	//�ڴ�������
	if (!m_buf.AddBuf((int)sock,bufdata,buflen))
	{
		ASSERT(FALSE);
		return FALSE;
	}
	UINT size=m_buf.GetBuffedSize((int)sock);
	if (size>0)
	{
		UINT len;
		UINT nDeletelen=0;
		char *buf=(char *)m_buf.GetBuf((int)sock,&len);
		while(buf && len>0)
		{
			UINT readylen=IsBufferReady(cls,sock,buf,len,paddr,adddata);
			if (readylen>0)
			{
				BufferedReceiveHandler(cls,sock,buf,readylen,paddr,adddata);
				len-=readylen;
				buf+=readylen;
				nDeletelen+=readylen;
			}
			if (readylen==0 || len==0) break;
		}
		m_buf.ReleaseGetBufLock((int)sock,nDeletelen);
	}
	return TRUE;
}

void IRawSocketBufferedEventHandler::ErrorHandler(ISocketLayer *cls,RAWSOCKET sock,DWORD errcode,void *adddata)
{
	m_buf.Empty((int)sock);
}

ISocketLayer::ISocketLayer()
{
#ifdef _WIN32
	WSADATA wsaData;
	WSAStartup(SocketVersion,&wsaData);
#endif
	m_nLastError=0;
	m_handler=NULL;
	m_adddata=NULL;
}

ISocketLayer::~ISocketLayer(void)
{
#ifdef _WIN32
	WSACleanup();
#endif
}

RAWSOCKET ISocketLayer::CreateSocketByHost(const char *pchHost,U16 peerport,U16 localport,RawProtocol protocol,BOOL bSelect)
{
	U32 ip=0;
	if (isalpha(*pchHost))
	{
		hostent* remoteHost=NULL;
		remoteHost=gethostbyname(pchHost);
		if (remoteHost)
			ip=(U32)((LPIN_ADDR)remoteHost->h_addr)->s_addr;
		else
			return INVALID_SOCKET;
	}
	else
	{
		ip=inet_addr(pchHost);
	}
	return CreateSocket(ntohl(ip),peerport,localport,protocol,bSelect);
}

BOOL ISocketLayer::SetSocketMode(RAWSOCKET s,BOOL bBlock)
{
	int iMode = bBlock? 0:1;
	return ioctlsocket(s, FIONBIO, (u_long *) &iMode)==0;
}

/**
* @brief ������Ϣ��Ӧ��
* @param handler	��Ϣ��Ӧ��ָ��
* @param adddata	��������
*/
void ISocketLayer::SetHandler(IRawSocketEventHandler *handler,void *adddata)
{
	m_handler=handler;m_adddata=adddata;
}

void ISocketLayer::SetUdpSocketAutoCloseBehavior(RAWSOCKET s,BOOL bAutoClose)
{
#ifdef _WIN32
	if (IsNT())
	{
		DWORD dwBytesReturned=0;
		BOOL bNewBehavior=FALSE;
		WSAIoctl(s,SIO_UDP_CONNRESET,&bAutoClose,sizeof(bAutoClose),NULL,0,&dwBytesReturned,NULL,NULL);
	}
#endif
}

int ISocketLayer::GetLastError(){return m_nLastError;}

U16 ISocketLayer::GetLocalPort(RAWSOCKET socket)
{
	struct sockaddr_in sin;
	socklen_t socklen = sizeof(struct sockaddr_in);
	getsockname(socket,(struct sockaddr *)&sin,&socklen);
	return ntohs(sin.sin_port);
}

CRawSocket::CRawSocket():ISocketLayer()
{
	MYFD_ZERO(&m_fdPool);
	m_rawthread.SetCallFunc(MyThreadCallBack);
	//init thread
	StartListen();
}
CRawSocket::~CRawSocket(void)
{
	//laterme,close socket
	m_mtxFd.Lock();
	MYFD_ZERO(&m_fdPool);
	m_mtxFd.Unlock();
	StopListen();
}

RAWSOCKET CRawSocket::CreateSocket(U32 peerip,U16 peerport,U16 localport,RawProtocol protocol,BOOL bSelect)
{
	if (peerip==0 && peerport!=0) return INVALID_SOCKET;
	BOOL bListenMode=FALSE;
	//tcp���ӣ������peer�˿ڱ�ʾ��Ҫ����connect
	//tcp���ӣ������peer�˿ڣ���ʾΪ������ģʽ���󶨶˿ڲ�����
	RAWSOCKET sock=INVALID_SOCKET;
	//create socket
	if (protocol==RawProtocol_Tcp)
	{
		sock=socket(AF_INET,SOCK_STREAM,0);
		if (sock==INVALID_SOCKET)
		{
			m_nLastError=WSAGetLastError();
			return INVALID_SOCKET;
		}
#if defined(_WIN32) && !defined(_WIN32_WCE)
		BOOL nodelayval = TRUE;
		setsockopt(sock,IPPROTO_TCP,TCP_NODELAY,(const char *)&nodelayval,sizeof(BOOL));
#endif
	}
	else if (protocol==RawProtocol_Udp)
	{
		sock=socket(AF_INET,SOCK_DGRAM,0);
		if (sock==INVALID_SOCKET)
		{
			m_nLastError=WSAGetLastError();
			return INVALID_SOCKET;
		}
	}
	//set buffer size
#if !defined(_WIN32_WCE) && !defined(_MIPS)
	int nrcvbuf=307200; //and now the default buffer is 8192
	setsockopt(sock,SOL_SOCKET,SO_SNDBUF,(char *)&nrcvbuf,sizeof(nrcvbuf));
	nrcvbuf=204800;
	setsockopt(sock,SOL_SOCKET,SO_RCVBUF,(char *)&nrcvbuf,sizeof(nrcvbuf));
#endif
	//bind local port
	struct sockaddr_in sin;
	memset(&sin,0,sizeof(struct sockaddr_in));
	sin.sin_family=AF_INET;
	sin.sin_port=htons(localport);
	if (bind(sock,(const struct sockaddr *)&sin,sizeof(sin))!=0)
	{
		sin.sin_port=0;
		//���԰������˿�
		if (bind(sock,(const struct sockaddr *)&sin,sizeof(sin))!=0)
		{
			m_nLastError=WSAGetLastError();
			return INVALID_SOCKET;
		}
	}
	if (protocol==RawProtocol_Tcp)
	{
		if (peerip!=0 && peerport!=0)
		{
			struct sockaddr_in thataddr;
			memset(&thataddr,0,sizeof(struct sockaddr_in));
			thataddr.sin_family = AF_INET;
			thataddr.sin_addr.s_addr = htonl(peerip);
			thataddr.sin_port = htons(peerport);
			if (connect(sock,(LPSOCKADDR)&thataddr,sizeof(thataddr))==SOCKET_ERROR)
			{
				m_nLastError=WSAGetLastError();
				return INVALID_SOCKET;
			}
		}
		else
		{
			if (protocol==RawProtocol_Tcp)
			{
				if (listen(sock,50)==SOCKET_ERROR)
				{
					m_nLastError=WSAGetLastError();
					return INVALID_SOCKET;
				}
				bListenMode=TRUE;
				ASSERT((int)sock!=1);
				m_rawthread.StartThread((int)sock,this,TIMEVAL_NOTDELAY);
				m_sListening.push_back((int)sock);
			}
		}
	}
	if (!bListenMode && bSelect)
	{
#ifdef USE_LINUX_MULTIDIRECTRECEIVE
		SetSocketMode(sock,FALSE);
#endif
		m_mtxFd.Lock();
		MYFD_SET(sock,&m_fdPool);
		m_mtxFd.Unlock();
	}
#ifdef NO_USE_MSG_PEEK
	if (protocol==RawProtocol_Tcp)
	{
		m_peeklock.Lock();
		//�ȴ���entry
		m_buf.AddBuf((int)sock,"",0);
		m_peeklock.Unlock();
	}
#endif
	return sock;
}


void CRawSocket::FreeSocket(RAWSOCKET sock,DWORD errcode,BOOL bNotify)
{
	m_mtxFd.Lock();
	MYFD_CLR(sock,&m_fdPool);
	m_mtxFd.Unlock();
	closesocket(sock);
#ifdef NO_USE_MSG_PEEK
	m_peeklock.Lock();
	m_buf.DeleteEntry((int)sock);
	m_peeklock.Unlock();
#endif
	if (m_handler && bNotify)
		m_handler->ErrorHandler(this,sock,errcode,m_adddata);
}

BOOL CRawSocket::Send(RAWSOCKET sock,const void *buf,int len,const struct sockaddr_in *paddr,int TryTime)
{
	if (sock==INVALID_SOCKET) return FALSE;
	//CMyDebug(_T("sock send:%d,%d"),sock,len);
	//m_mtxSendLock.Lock();
	int sent=0;
	int ret;
	while(sent<len)
	{
		if (paddr)
			ret=sendto(sock,(const char *)buf+sent,len-sent,0,(const sockaddr *)paddr,sizeof(struct sockaddr_in));
		else
			ret=send(sock,(const char *)buf+sent,len-sent,0);
		if (ret<=0)
		{
			int lasterr=WSAGetLastError();
			if (IsWouldBlock(lasterr))
			{
				if (TryTime!=-1)
				{
					TryTime--;
					if (TryTime==0)
					{
						//break the timeout socket
						/*if (m_handler)
							m_handler->ErrorHandler(this,sock,m_nLastError,m_adddata);*/
						//FreeSocket(sock);
						//CMyDebug(_T("sock send timeout:%d,%d"),sock,len);
						return FALSE;
					}
				}
				Sleep(1);
				continue;
			}
			m_nLastError=lasterr;
			//m_mtxSendLock.Unlock();
			/*if (m_handler)
				m_handler->ErrorHandler(this,sock,m_nLastError,m_adddata);*/
			//FreeSocket(sock);
			CMyDebug(_T("sock send error:%d,%d"),sock,lasterr);
			return FALSE;
		}
		sent+=ret;
	}
	//m_mtxSendLock.Unlock();
	//CMyDebug(_T("sock send finish:%d,%d"),sock,len);
	return TRUE;
}

BOOL CRawSocket::Send(RAWSOCKET sock,const void *buf,int len,U32 peerip,U16 peerport,int TryTime)/*-1*/
{
	if (peerip!=0 && peerport!=0)
	{
		struct sockaddr_in addr;
		memset(&addr,0,sizeof(struct sockaddr_in));
		addr.sin_family=AF_INET;
		addr.sin_addr.s_addr=htonl(peerip);
		addr.sin_port=htons(peerport);
		return Send(sock,buf,len,&addr,TryTime);
	}
	return Send(sock,buf,len,NULL,TryTime);
}

int CRawSocket::ReceiveFor(RAWSOCKET sock,void *buf,int len,U32 *peerip,U16 *peerport,int nWaiting)
{
	struct sockaddr_in from;
	int fromlen=sizeof(from);
	int ret;
	DWORD dw=GetTickCount()+nWaiting;
	do
	{
		ret=Receive(sock,buf,len,MSG_PEEK,peerip,peerport);
		if (ret==-1) return -1;
		if (ret>0)
			return Receive(sock,buf,len,0,peerip,peerport);
		if (nWaiting<=0) return 0;
		Sleep(100);
	}while(GetTickCount()<dw);
	return 0;
}
int CRawSocket::Receive(RAWSOCKET sock,void *buf,int len,int flag,U32 *peerip,U16 *peerport)
{
	int ret;
	if (peerip && peerport)
	{
		struct sockaddr_in addr;
		socklen_t len=sizeof(sockaddr_in);
		ret=::recvfrom(sock,(char *)buf,len,flag,(SOCKADDR *)&addr,&len);
		*peerip=ntohl(addr.sin_addr.s_addr);
		*peerport=ntohs(addr.sin_port);
	}
	else
		ret=recv(sock,(char *)buf,len,flag);
	return ret;
}

int CRawSocket::Receive(RAWSOCKET sock,void *buf,int len,int flag,struct sockaddr *addr,socklen_t *fromlen)
{
	int ret;
	if (addr && fromlen)
		ret=::recvfrom(sock,(char *)buf,len,flag,addr,fromlen);
	else
		ret=::recv(sock,(char *)buf,len,flag);
	return ret;
}

void CRawSocket::SetSelectSocket(RAWSOCKET socket,BOOL bSelect)
{
	m_mtxFd.Lock();
	if (bSelect)
	{
#ifdef USE_LINUX_MULTIDIRECTRECEIVE
		SetSocketMode(socket,FALSE);
#endif
		MYFD_SET(socket,&m_fdPool);
	}
	else
	{
		MYFD_CLR(socket,&m_fdPool);
	}
	m_mtxFd.Unlock();
}

void CRawSocket::StopListen()
{
	m_rawthread.KillThread(RAWSOCKET_THREADID_RECEIVE);
	list<int>::iterator it=m_sListening.begin();
	for(;it!=m_sListening.end();it++)
	{
		int s=*it;
		if ((RAWSOCKET)s!=INVALID_SOCKET)
		{
			closesocket((RAWSOCKET)s);
			ASSERT(s!=1);
			m_rawthread.KillThread(s);
		}
	}
	m_sListening.clear();
}

void CRawSocket::StartListen()
{
	m_rawthread.StartThread(RAWSOCKET_THREADID_RECEIVE,this,TIMEVAL_NOTDELAY);
}

void CRawSocket::MyThreadCallBack(int ThreadId,CMyThread *pCls,void *data)
{
	if (ThreadId==RAWSOCKET_THREADID_RECEIVE)
	{
		((CRawSocket *)data)->RecvServiceThread(data);
	}
	else
	{
		((CRawSocket *)data)->ListenServiceThread(ThreadId,data);
	}
}

#ifdef NO_USE_MSG_PEEK
int CRawSocket::recvfrom(RAWSOCKET s,char *buf,int len,int flags,sockaddr *from,socklen_t *fromlen)
{
	CMySingleLock l(&m_peeklock);
	if (flags&MSG_PEEK)
	{
		if (flags==MSG_PEEK)
			flags=0;
		else
			flags&=~MSG_PEEK;
		int ret=::recvfrom(s,buf,len,flags,from,fromlen);
		//��������udpģʽ��ֱ�ӷ���
		if (ret<=0 || m_buf.IsHaveData((int)s)==FALSE) return ret;
		if (ret>0) m_buf.AddBuf((int)s,buf,ret);
		UINT bl;
		void *bf=m_buf.GetBuf((int)s,&bl);
		ASSERT(bf && bl>0);
		ret=min((UINT)len,bl);
		memcpy(buf,bf,ret);
		m_buf.ReleaseGetBufLock((int)s);
		return ret;
	}
	else
	{
		//udpֱ�ӷ���len��tcp�жϻ����Ƿ�
		ASSERT(m_buf.IsHaveData((int)s)==FALSE || m_buf.GetBuffedSize((int)s)>=len);
		//�������
		m_buf.RemoveBuf((int)s,len);
		return len;
	}
	return -1;
}
#endif

DWORD CRawSocket::RecvServiceThread(LPVOID lpParam)
{
	struct sockaddr_in scaddr;
	socklen_t caddsize;
	timeval ti;
	long ret,sret;
	//while(1)
	{
		//if (!m_hRecvServiceThread) break;//exit the thread
		char buf[MAX_PACKET_LEN];
		/*if (m_fdSocketPool.fd_count==0)
		{
			Sleep(100);
			return 0;//continue;
		}*/
#ifdef USE_LINUX_EPOLL
		sret=m_fdPool.poll(1000);
#elif defined(USE_LINUX_DIRECTRECEIVE)
		sret=(long)m_fdPool;
#elif defined(USE_LINUX_MULTIDIRECTRECEIVE)
		sret=m_fdPool.empty()?-1:1;
#else
		fd_set set,errset;
		myfd_set orgset;
		m_mtxFd.Lock();
		memcpy(&orgset,&m_fdPool,sizeof(myfd_set));
		m_mtxFd.Unlock();
		U32 fdcnt=orgset.fd_count;
		MYFD_COPY(&set,&orgset,fdcnt);
		FD_COPY(&set,&errset);
		ti.tv_sec=1;
		ti.tv_usec=0;
		sret=select(fdcnt+1,&set,NULL,&errset,&ti);//param 1 is ingore in windows platfrom
#endif
		//if (!m_hRecvServiceThread) break;//exit the thread
		if (sret<0)
		{
			//PrintLog("Select Error:ret:%d,Error:%d,the socket closed",ret,WSAGetLastError());
#ifdef USE_LINUX_EPOLL
			if (errno!=EINTR)
			{
				CMyDebug(_T("Epoll Socket Error:%d"),errno);
				Sleep(200);
			}
#else//included USE_LINUX_DIRECTRECEIVE USE_LINUX_MULTIDIRECTRECEIVE
			Sleep(1);
#endif
			return 0;//continue;
		}
		else if (sret>0)
		{
			RAWSOCKET s;
			unsigned long i;
#ifdef USE_LINUX_EPOLL
			for(i=0;i<sret;i++)
#elif defined(USE_LINUX_DIRECTRECEIVE)
			;
#elif defined(USE_LINUX_MULTIDIRECTRECEIVE)
			m_mtxFd.Lock();
			set<RAWSOCKET>::iterator itor=m_fdPool.begin();
			while(itor!=m_fdPool.end())
#else
			for(i=0;i<orgset.fd_count;i++)
#endif
			{
				//test for error
				//the socket have some error.
				//PrintLog("ret:%d receive Error:%d,the socket %d closed",ret,errcode,set.fd_array[i]);
#ifdef USE_LINUX_EPOLL
				if (m_fdPool.iserr(i))
				{
					s=m_fdPool.fd(i);
					m_fdPool.del(s);
					CMyDebug(_T("Epoll error:%d,%d"),i,s);
#elif defined(USE_LINUX_DIRECTRECEIVE)
				if (0)
				{
					s=m_fdPool;
#elif defined(USE_LINUX_MULTIDIRECTRECEIVE)
				if (0)
				{
					s=INVALID_SOCKET;
#else
				if (FD_ISSET(orgset.fd_array[i],&errset))
				{
					s=orgset.fd_array[i];
#endif
					m_nLastError=WSAGetLastError();
					FreeSocket(s,m_nLastError);
				}
				//test for receive
#ifdef USE_LINUX_EPOLL
				if (m_fdPool.isrecv(i))
				{
					s=m_fdPool.fd(i);
#elif defined(USE_LINUX_DIRECTRECEIVE)
				if (1)
				{
					s=m_fdPool;
#elif defined(USE_LINUX_MULTIDIRECTRECEIVE)
				if (1)
				{
					s=*itor;
					itor++;//because of FreeSocket maybe call below,itor maybe dirty if ++ at the end
#else
				if (FD_ISSET(orgset.fd_array[i],&set))
				{
					s=orgset.fd_array[i];
#endif
					caddsize=sizeof(scaddr);
					memset(&scaddr,0,sizeof(scaddr));
#if defined(USE_LINUX_MULTIDIRECTRECEIVE)
					ret=recvfrom(s,buf,MAX_PACKET_LEN,MSG_PEEK|MSG_DONTWAIT,(struct sockaddr *)&scaddr,&caddsize);
#else
					ret=recvfrom(s,buf,MAX_PACKET_LEN,MSG_PEEK,(struct sockaddr *)&scaddr,&caddsize);
#endif
					if(ret>0)
					{
						BOOL bReceive=TRUE;
						if (m_handler)
							bReceive=m_handler->ReceiveHandler(this,s,buf,ret,&scaddr,m_adddata);
						if (bReceive)
							ret=recvfrom(s,buf,ret,0,(struct sockaddr *)&scaddr,&caddsize);
					}
					else
					{
						//the socket have some error.
						int lasterr=WSAGetLastError();
						if (!IsWouldBlock(lasterr))
						{
#ifdef USE_LINUX_EPOLL
							m_fdPool.del(s);
							CMyDebug(_T("Epoll receive error:%d,%d,%s"),lasterr,s,strerror(lasterr));
#endif
							m_nLastError=lasterr;
							//linux errno ERESTARTSYS 512,��˵����һ�ξͿ�����
							CMyDebug(_T("ret:%d receive Error:%d,the socket %d closed"),ret,lasterr,s);
							FreeSocket(s,m_nLastError);
						}
#ifdef USE_LINUX_DIRECTRECEIVE
						else
							Sleep(1);
#endif
					}
				}
			}
#ifdef USE_LINUX_MULTIDIRECTRECEIVE
			m_mtxFd.Unlock();
			Sleep(1);
#endif
		}
	}
	return 0;
}

DWORD CRawSocket::ListenServiceThread(int Threadid,LPVOID lpParam)
{
	RAWSOCKET sock=(RAWSOCKET)Threadid;
	RAWSOCKET sockTemp;
	struct sockaddr_in addr;
	socklen_t addrlen;

	addrlen=sizeof(struct sockaddr_in);
	sockTemp=accept(sock,(SOCKADDR*)&addr,&addrlen); 
	if (sockTemp!=INVALID_SOCKET)
	{
		struct sockaddr_in sin;
		socklen_t socklen = sizeof(struct sockaddr_in);
		getsockname(sockTemp,(struct sockaddr *)&sin,&socklen);
#ifdef USE_LINUX_MULTIDIRECTRECEIVE
		SetSocketMode(sockTemp,FALSE);
#endif
		m_mtxFd.Lock();
		MYFD_SET(sockTemp,&m_fdPool);
		m_mtxFd.Unlock();
		if (m_handler)
			m_handler->AcceptHandler(this,sock,sockTemp,&sin,&addr,m_adddata);
	}
	else
		Sleep(500);
	return 0;
}
