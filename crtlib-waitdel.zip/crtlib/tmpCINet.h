#pragma once

#ifdef _WIN32
	#include <wininet.h>
	#pragma comment(lib,"wininet.lib")
	#include <urlmon.h>
	#pragma comment(lib,"Urlmon.lib")
	#include "shlwapi.h"
#else
#include "SocketLayer.h"
#include "HttpServer.h"

class IBindStatusCallback
{
public:
	virtual HRESULT OnStopBinding(HRESULT hresult,LPCWSTR szError)=0;
	virtual HRESULT OnProgress(ULONG ulProgress,ULONG ulProgressMax,ULONG ulStatusCode,LPCWSTR szStatusText)=0;
	virtual HRESULT OnDataAvailable(DWORD grfBSCF,DWORD dwSize,void *pformatetc,void *pstgmed)=0;
};

class CINetRaw;
typedef class CINetRaw* HINTERNET;

#define INTERNET_OPEN_TYPE_PRECONFIG                    0   // use registry configuration
#define INTERNET_OPEN_TYPE_DIRECT                       1   // direct to net
#define INTERNET_FLAG_RELOAD            0x80000000  // retrieve the original item
#define INTERNET_FLAG_NO_CACHE_WRITE    0x04000000  // don't write this item to the cache
#define INTERNET_FLAG_NO_AUTO_REDIRECT	0x00200000	// don't handle redirections automatically
#define INTERNET_DEFAULT_HTTP_PORT      80          //    "     "  HTTP   "
#define INTERNET_SERVICE_HTTP   3

#define HTTP_QUERY_FLAG_NUMBER                  0x20000000
#define HTTP_QUERY_VALUE_RANGE					0x00FFFFFF
#define HTTP_QUERY_CONTENT_LENGTH               5
#define HTTP_QUERY_STATUS_CODE					19
#define HTTP_QUERY_LOCATION						33
#define HTTP_QUERY_RAW_HEADERS_CRLF				22
#define HTTP_QUERY_CONTENT_RANGE				53

#define SOCKET_TEMP								0x01000000

class CINetRaw : public IRawSocketBufferedEventHandler
{
public:
	CINetRaw()
	{
		s=INVALID_SOCKET;
		m_s.SetHandler(this,NULL);
		m_state=0;
		m_statuscode=0;
		m_len=0;
		m_readedlen=0;
		m_ref=0;
		m_agent="Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; ku6speedup)";
		m_verb="GET";
		m_accepttype="*/*";
		m_conntype="close";
		m_bAutoParseRedirect=TRUE;
	}
	virtual ~CINetRaw()
	{
		ResetThings(FALSE);
	}
	virtual UINT IsBufferReady(ISocketLayer *cls,RAWSOCKET sock,const void *bufdata,int buflen,struct sockaddr_in *paddr,void *adddata)
	{
		if (sock!=s) return buflen;
		if (m_state==0)
		{
			static char crbf[]="\r\n\r\n";
			static int crbflen=(int)strlen(crbf);
			const char *tmpcrbf=CHttpMisc::BinSearch((const char *)bufdata,buflen,crbf,crbflen);
			if (!tmpcrbf) return 0;
			UINT headerlen=(UINT)(UINT_PTR)(tmpcrbf-(const char *)bufdata+crbflen);
			return headerlen;
		}
		//else if (m_state==1)
		return buflen;
	}
	virtual void BufferedReceiveHandler(ISocketLayer *cls,RAWSOCKET sock,const void *bufdata,int buflen,struct sockaddr_in *paddr,void *adddata)
	{
		if (sock!=s)
		{
			//CMyDebug(_T("CINet:Skip old socket buffer %d"),buflen);
			return;
		}
		if (m_state==0)
		{
			CStringA str;
			str.SetString((const char *)bufdata,buflen);
			m_rawbuffer=str;
			//CMyDebug(_T("CINet:Receive header:%s"),(LPCTSTR)m_rawbuffer);
			int i=0;
			do
			{
				CStringToken t(str.Tokenize(_T("\r\n"),i),_T(":"));
				CString key=t.GetNextToken();
				key.Trim();
				if (!key.IsEmpty())
				{
					if (key.CompareNoCase(_T("Content-Length"))==0)
					{
						m_len=(UINT)_ttoi(t.GetNextToken());
						//CMyDebug(_T("Content-Length is %u"),m_len);
					}
					else if (key.CompareNoCase(_T("Content-Range"))==0)
					{
						m_contentrange=t.GetRemainContent();
						m_contentrange.TrimLeft();
						//CMyDebug(_T("Content-Range is %s"),(LPCTSTR)m_contentrange);
					}
					else if (key.CompareNoCase(_T("Location"))==0)
					{
						m_location=t.GetRemainContent();
						m_location.TrimLeft();
						//CMyDebug(_T("location is %s"),(LPCTSTR)m_location);
					}
					else if (key.Left(5).CompareNoCase(_T("HTTP/"))==0)
					{
						CStringToken t(key,_T(" "));
						t.GetNextToken();
						m_statuscode=(UINT)_ttoi(t.GetNextToken());
						//CMyDebug(_T("Http Result Code is %u"),m_statuscode);
					}
				}
			}while(i!=-1);
			if (((UINT)(m_statuscode/100))>=4)
			{
				//������
				ResetThings();
			}
			else if (m_bAutoParseRedirect && ((UINT)(m_statuscode/100))==3)
			{
				//CMyDebug(_T("Auto Redirecting"));
				CString location=m_location;
				RAWSOCKET tmps=s;
				s=SOCKET_TEMP;//��socket��ʱ������һ��ֵ���ȴ��µ�����
				m_statuscode=0;
				m_len=0;
				m_location.Empty();
				m_rawbuffer.Empty();
				m_contentrange.Empty();
				//ReleaseRef();//����s=SOCKET_TEMP��ʶ�����������ü���
				if (!InternetOpenUrl(location,m_addheaders,m_addheaders.GetLength(),(DWORD)-1,0))
				{
					//���ӳ����ˣ��ͷ�s֪ͨ
					s=INVALID_SOCKET;
				}
				MyFreeSocket(tmps);//�ͷ�֮ǰ������
			}
			else
				m_state=1;
		}
		else if (m_state==1)
		{
			//CMyDebug(_T("Receive %u data"),buflen);
			m_databuf.AddBuf(bufdata,buflen);
		}
	}
	virtual void ErrorHandler(ISocketLayer *cls,RAWSOCKET sock,DWORD errcode,void *adddata)
	{
		IRawSocketBufferedEventHandler::ErrorHandler(cls,sock,errcode,adddata);
		if (sock==s)
		{
			//CMyDebug(_T("ErrorHandler"));
			ResetThings();
		}
	}
	void AddRef()
	{
		m_ref++;
	}
	void ReleaseRef()
	{
		m_ref--;
		ASSERT(m_ref>=0);
		if (m_ref<=0) delete this;
	}
	void SetAgent(CStringA agent){m_agent=agent;}
	void SetFlag(DWORD nFlags)
	{
		if (nFlags==(DWORD)-1) return;//���ø���
		//only support these flags
		ASSERT(nFlags==(nFlags&(INTERNET_FLAG_RELOAD|INTERNET_FLAG_NO_CACHE_WRITE|INTERNET_FLAG_NO_AUTO_REDIRECT)));
		m_bAutoParseRedirect=!(nFlags&INTERNET_FLAG_NO_AUTO_REDIRECT);
	}
	HINTERNET InternetConnect(LPCSTR lpszServerName,unsigned short nServerPort,LPCSTR lpszUserName,LPCSTR lpszPassword,DWORD dwService,DWORD dwFlags,DWORD_PTR dwContext)
	{
		//do not support username/password
		ASSERT(lpszUserName==NULL && lpszPassword==NULL);
		//only support http
		ASSERT(dwService==INTERNET_SERVICE_HTTP);
		SetFlag(dwFlags);
		m_host=lpszServerName;
		RAWSOCKET tmps=s;
		s=SOCKET_TEMP;//���ҵ�ǰs��ȷ�����������ڽ��յ�����д�뵽��ǰ����
		m_state=0;
		m_statuscode=0;
		m_len=0;
		m_location.Empty();
		m_rawbuffer.Empty();
		m_contentrange.Empty();
		m_databuf.Empty();
		s=m_s.CreateSocket(ntohl(ISocketLayer::GetIpFromHostName(lpszServerName)),nServerPort);
		MyFreeSocket(tmps);
		if (s!=INVALID_SOCKET)
		{
			AddRef();
			return this;
		}
		return NULL;
	}
	HINTERNET InternetOpenUrl(LPCSTR lpszUrl,LPCSTR lpszHeaders,DWORD dwHeadersLength,DWORD dwFlags,DWORD_PTR dwContext)
	{
		CStringA url=lpszUrl;
		CStringA path;
		unsigned short port=INTERNET_DEFAULT_HTTP_PORT;
		url.Replace(_T("http://"),_T(""));
		int i=0;
		CStringA ip=url.Tokenize(_T(":/"),i);
		if (ip.IsEmpty()) return NULL;
		int pos=url.Find(_T(":"));
		if (pos!=-1)
			port=(unsigned short)_ttoi(url.Mid(pos+1));
		else
			pos=0;
		pos=url.Find(_T("/"));
		if (pos==-1)
			path=_T("/");
		else
			path=url.Mid(pos);
		SetFlag(dwFlags);
		m_host=ip;
		BOOL bIntCall=(s==SOCKET_TEMP);
		RAWSOCKET tmps=s;
		s=SOCKET_TEMP;//���ҵ�ǰs��ȷ�����������ڽ��յ�����д�뵽��ǰ����
		if (!bIntCall)
		{
			m_state=0;
			m_statuscode=0;
			m_len=0;
			m_location.Empty();
			m_rawbuffer.Empty();
			m_contentrange.Empty();
			m_databuf.Empty();
		}
		s=m_s.CreateSocket(ntohl(ISocketLayer::GetIpFromHostName(ip)),port);
		if (!bIntCall)
			MyFreeSocket(tmps);
		if (s!=INVALID_SOCKET)
		{
			m_reqobj=path;
			SendHeaders(lpszHeaders,dwHeadersLength);
			if (bIntCall) return this;
			if (WaitForResult())
			{
				AddRef();
				return this;
			}
		}
		return NULL;
	}
	HINTERNET HttpOpenRequest(LPCSTR lpszVerb,LPCSTR lpszObjectName,LPCSTR lpszVersion,LPCSTR lpszReferrer,LPCSTR *lplpszAcceptTypes,DWORD dwFlags,DWORD_PTR dwContext)
	{
		//do not support these params
		ASSERT(lpszVersion==NULL && lpszReferrer==NULL && lplpszAcceptTypes==NULL);
		SetFlag(dwFlags);
		m_verb=lpszVerb;
		m_reqobj=lpszObjectName;
		AddRef();
		return this;
	}
	BOOL HttpSendRequest(LPCSTR lpszHeaders,DWORD dwHeadersLength,LPVOID lpOptional,DWORD dwOptionalLength)
	{
		SendHeaders(lpszHeaders,dwHeadersLength,lpOptional,dwOptionalLength);
		return WaitForResult();
	}
	BOOL HttpQueryInfo(DWORD dwInfoLevel,LPVOID lpBuffer,LPDWORD lpdwBufferLength,LPDWORD lpdwIndex)
	{
		if (dwInfoLevel&HTTP_QUERY_FLAG_NUMBER)
		{
			dwInfoLevel&=HTTP_QUERY_VALUE_RANGE;
			ASSERT(*lpdwBufferLength==sizeof(UINT));
			if (dwInfoLevel==HTTP_QUERY_STATUS_CODE)
				*(UINT *)lpBuffer=m_statuscode;
			else if (dwInfoLevel==HTTP_QUERY_CONTENT_LENGTH)
				*(UINT *)lpBuffer=m_len;
			else
				return FALSE;
		}
		else
		{
			dwInfoLevel&=HTTP_QUERY_VALUE_RANGE;
			CStringA *tmp=NULL;
			if (dwInfoLevel==HTTP_QUERY_LOCATION)
				tmp=&m_location;
			else if (dwInfoLevel==HTTP_QUERY_RAW_HEADERS_CRLF)
				tmp=&m_rawbuffer;
			else if (dwInfoLevel==HTTP_QUERY_CONTENT_RANGE)
				tmp=&m_contentrange;
			if (!tmp) return FALSE;
			if ((*lpdwBufferLength)<tmp->GetLength()) return FALSE;
			*lpdwBufferLength=tmp->GetLength();
			strcpy((char *)lpBuffer,*tmp);
		}
		return TRUE;
	}
	BOOL InternetReadFile(LPVOID lpBuffer,DWORD dwNumberOfBytesToRead,LPDWORD lpdwNumberOfBytesRead)
	{
		UINT len;
		void *buf;
		unsigned char *w=(unsigned char *)lpBuffer;
		*lpdwNumberOfBytesRead=0;
		DWORD dw=GetTickCount();
		while(dwNumberOfBytesToRead>0 && (m_len==0 || m_readedlen<m_len))
		{
			UINT readed=0;
			buf=m_databuf.GetBuf(&len);
			if (buf && len>0)
			{
				readed=min(len,dwNumberOfBytesToRead);
				memcpy(w,buf,readed);
				//CMyDebug(_T("Readed %u data"),readed);
				dwNumberOfBytesToRead-=readed;
				w+=readed;
				*lpdwNumberOfBytesRead+=readed;
				m_readedlen+=readed;
			}
			m_databuf.ReleaseGetBufLock(readed);
			if (len==0 && s==INVALID_SOCKET)
			{
				//CMyDebug(_T("Receive Done."));
				break;
			}
			if (GetTickCount()-dw>120000)
			{
				CMyDebug(_T("Network Timeout"));
				return FALSE;
			}
		}
		return TRUE;
	}
protected:
	void MyFreeSocket(RAWSOCKET rs)
	{
		if (rs!=INVALID_SOCKET && rs!=SOCKET_TEMP)
			m_s.FreeSocket(rs);
	}
	BOOL WaitForResult()
	{
		while(1)
		{
			if (m_state>=1)
			{
				//CMyDebug(_T("Header Parser Finish."));
				return TRUE;
			}
			if (s==INVALID_SOCKET)
			{
				//CMyDebug(_T("Http Have Error,return error."));
				return FALSE;
			}
			Sleep(1);
		}
		return TRUE;
	}
	void SendHeaders(LPCSTR lpszHeaders,DWORD dwHeadersLength,LPVOID lpOptional=NULL,DWORD dwOptionalLength=0)
	{
		CString addheader;
		if (lpszHeaders && dwHeadersLength!=0)
		{
			CString head,tmp;
			CStringToken t;
			head.SetString(lpszHeaders,dwHeadersLength);
			int i=0;
			do{
				tmp=head.Tokenize(_T("\r\n"),i);
				if (!tmp.IsEmpty())
				{
					t.Init(tmp,_T(":"));
					CString key=t.GetNextToken();
					key.Trim();
					if (key.CompareNoCase(_T("User-Agent"))==0)
					{
						m_agent=t.GetRemainContent();
						m_agent.TrimLeft();
					}
					else if (key.CompareNoCase(_T("Referer"))==0)
					{
						m_refer=t.GetRemainContent();
						m_refer.TrimLeft();
					}
					else if (key.CompareNoCase(_T("Host"))==0)
					{
						m_host=t.GetRemainContent();
						m_host.TrimLeft();
					}
					else if (key.CompareNoCase(_T("Accept"))==0)
					{
						m_accepttype=t.GetRemainContent();
						m_accepttype.TrimLeft();
					}
					else if (key.CompareNoCase(_T("Connection"))==0)
					{
						m_conntype=t.GetRemainContent();
						m_conntype.TrimLeft();
					}
					else
						addheader+=tmp+_T("\r\n");
				}
			}while(i!=-1);
		}
		m_addheaders=addheader;
		CString contentlength;
		if (lpOptional && dwOptionalLength!=0)
			contentlength.Format(_T("Content-Type: application/x-www-form-urlencoded\r\nContent-Length: %u\r\n"),dwOptionalLength);
		CString refer;
		if (!m_refer.IsEmpty())
			refer=_T("\r\nReferer: ")+m_refer;
		addheader=m_verb+_T(" ")+m_reqobj+_T(" HTTP/1.1\r\nAccept: ")+m_accepttype+_T("\r\nUser-Agent: ")+m_agent+refer+_T("\r\nHost: ")+m_host+_T("\r\n")+contentlength+m_addheaders+_T("Connection: ")+m_conntype+_T("\r\n\r\n");
		//CMyDebug(_T("Send Headers:%s"),(LPCTSTR)addheader);
		m_s.Send(s,(LPCTSTR)addheader,addheader.GetLength());
		if (lpOptional && dwOptionalLength!=0)
			m_s.Send(s,lpOptional,dwOptionalLength);
	}
	void ResetThings(BOOL bAddRef=TRUE)
	{
		if (!bAddRef) m_s.SetHandler(NULL,NULL);
		if (s!=INVALID_SOCKET)
		{
			RAWSOCKET tmps=s;
			s=INVALID_SOCKET;
			MyFreeSocket(tmps);
		}
		//m_state=0;
		//m_statuscode=0;
		//m_len=0;
		//m_location.Empty();
		//m_rawbuffer.Empty();
		//m_contentrange.Empty();
		//m_databuf.Empty();������ӿ�����ǰ�رգ����ﲻ��ջ���
	}
	CRawSocket m_s;
	volatile RAWSOCKET s;
	volatile int m_state;
	volatile int m_ref;
	BOOL m_bAutoParseRedirect;
	//return headers
	UINT m_statuscode;
	UINT m_len;
	UINT m_readedlen;
	CStringA m_location;
	CStringA m_rawbuffer;
	CStringA m_contentrange;
	//send headers
	CStringA m_agent;
	CStringA m_refer;
	CStringA m_verb;
	CStringA m_reqobj;
	CStringA m_host;
	CStringA m_accepttype;
	CStringA m_conntype;
	CStringA m_addheaders;
	CMyNewMemBuf m_databuf;
};

static HINTERNET InternetOpen(LPCSTR lpszAgent,DWORD dwAccessType,LPCSTR lpszProxy,LPCSTR lpszProxyBypass,DWORD dwFlags)
{
	HINTERNET h=new CINetRaw();
	h->SetAgent(lpszAgent);
	ASSERT(dwAccessType==INTERNET_OPEN_TYPE_DIRECT || dwAccessType==INTERNET_OPEN_TYPE_PRECONFIG);
	ASSERT(lpszProxy==NULL && lpszProxyBypass==NULL);
	h->SetFlag(dwFlags);
	h->AddRef();
	return h;
}

static HINTERNET InternetConnect(HINTERNET hInternet,LPCSTR lpszServerName,unsigned short nServerPort,LPCSTR lpszUserName,LPCSTR lpszPassword,DWORD dwService,DWORD dwFlags,DWORD_PTR dwContext)
{
	return hInternet->InternetConnect(lpszServerName,nServerPort,lpszUserName,lpszPassword,dwService,dwFlags,dwContext);
}

static HINTERNET InternetOpenUrl(HINTERNET hInternet,LPCSTR lpszUrl,LPCSTR lpszHeaders,DWORD dwHeadersLength,DWORD dwFlags,DWORD_PTR dwContext)
{
	return hInternet->InternetOpenUrl(lpszUrl,lpszHeaders,dwHeadersLength,dwFlags,dwContext);
}

static HINTERNET HttpOpenRequest(HINTERNET hConnect,LPCSTR lpszVerb,LPCSTR lpszObjectName,LPCSTR lpszVersion,LPCSTR lpszReferrer,LPCSTR *lplpszAcceptTypes,DWORD dwFlags,DWORD_PTR dwContext)
{
	return hConnect->HttpOpenRequest(lpszVerb,lpszObjectName,lpszVersion,lpszReferrer,lplpszAcceptTypes,dwFlags,dwContext);
}

static BOOL HttpSendRequest(HINTERNET hRequest,LPCSTR lpszHeaders,DWORD dwHeadersLength,LPVOID lpOptional,DWORD dwOptionalLength)
{
	return hRequest->HttpSendRequest(lpszHeaders,dwHeadersLength,lpOptional,dwOptionalLength);
}

static BOOL HttpQueryInfo(HINTERNET hRequest,DWORD dwInfoLevel,LPVOID lpBuffer,LPDWORD lpdwBufferLength,LPDWORD lpdwIndex)
{
	return hRequest->HttpQueryInfo(dwInfoLevel,lpBuffer,lpdwBufferLength,lpdwIndex);
}

static BOOL InternetReadFile(HINTERNET hFile,LPVOID lpBuffer,DWORD dwNumberOfBytesToRead,LPDWORD lpdwNumberOfBytesRead)
{
	return hFile->InternetReadFile(lpBuffer,dwNumberOfBytesToRead,lpdwNumberOfBytesRead);
}

static void InternetCloseHandle(HINTERNET hHandle)
{
	return hHandle->ReleaseRef();
}

#endif
