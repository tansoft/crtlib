#pragma once

/**
* @brief ��ƽ̨ϵͳ����ӳ����(windowsΪ��)
* @author Barry(barrytan@21cn.com,QQ:20962493)
* @2008-11-24 �½�
*/

typedef unsigned int U32;
typedef unsigned short U16;
typedef unsigned char U8;
typedef signed int I32;
typedef signed short I16;
typedef signed char I8;

//for SafeSet and SafeGet in arm
#include "inc.h"
#include "oem.h"

//windows os helper
#ifdef _WIN32
	#pragma warning(disable:4996)
	#ifdef _WIN32_WCE
		#define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA
		#pragma comment(linker, "/nodefaultlib:libc.lib")
		#pragma comment(linker, "/nodefaultlib:libcd.lib")

		// ע�� - ���ֵ����ΪĿ��� Windows CE OS �汾�Ĺ����Բ���ǿ
		#ifndef WINVER
			#define WINVER _WIN32_WCE
		#endif

		#ifndef VC_EXTRALEAN
		#define VC_EXTRALEAN		// �� Windows ͷ���ų�����ʹ�õ�����
		#endif

		#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// ĳЩ CString ���캯��������ʽ��
		#ifdef _CE_DCOM
		#define _ATL_APARTMENT_THREADED
		#endif

		// �ر� MFC ��ĳЩ�����������ɷ��ĺ��Եľ�����Ϣ������
		#define _AFX_ALL_WARNINGS

		#include <ceconfig.h>
		#if defined(WIN32_PLATFORM_PSPC) || defined(WIN32_PLATFORM_WFSP)
		#define SHELL_AYGSHELL
		#endif

		#include <afxwin.h>         // MFC ��������ͱ�׼���
		#include <afxext.h>         // MFC ��չ

		#ifndef _AFX_NO_OLE_SUPPORT
		#include <afxdtctl.h>		// MFC �� Internet Explorer 4 �����ؼ���֧��
		#endif


		#include <afxdisp.h>        // MFC �Զ�����

		#ifndef _AFX_NO_AFXCMN_SUPPORT
		#include <afxcmn.h>			// MFC �� Windows �����ؼ���֧��
		#endif // _AFX_NO_AFXCMN_SUPPORT

		#include <afxsock.h>		// MFC �׽�����չ


		#if defined(WIN32_PLATFORM_PSPC) || defined(WIN32_PLATFORM_WFSP)
		#ifndef _DEVICE_RESOLUTION_AWARE
		#define _DEVICE_RESOLUTION_AWARE
		#endif
		#endif

		#ifdef _DEVICE_RESOLUTION_AWARE
		#include "DeviceResolutionAware.h"
		#endif

		#ifdef SHELL_AYGSHELL
		#include <aygshell.h>
		#pragma comment(lib, "aygshell.lib") 
		#endif // SHELL_AYGSHELL

		#if (_WIN32_WCE < 0x500) && ( defined(WIN32_PLATFORM_PSPC) || defined(WIN32_PLATFORM_WFSP) )
			#pragma comment(lib, "ccrtrtti.lib")
			#ifdef _X86_	
				#if defined(_DEBUG)
					#pragma comment(lib, "libcmtx86d.lib")
				#else
					#pragma comment(lib, "libcmtx86.lib")
				#endif
			#endif
		#endif

		#include <altcecrt.h>
	#else
		#define VC_EXTRALEAN
		#ifndef WINVER
		#define WINVER 0x0501
		#endif

		#ifndef _WIN32_WINNT
		#define _WIN32_WINNT 0x0501
		#endif

		#ifndef _WIN32_WINDOWS
		#define _WIN32_WINDOWS 0x0501
		#endif

		#ifndef _WIN32_IE
		#define _WIN32_IE 0x0510
		#endif

		#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// ĳЩ CString ���캯��������ʽ��

		#define _AFX_ALL_WARNINGS
		#include <afxwin.h>         // MFC ���ĺͱ�׼���
	#endif
	#ifdef _DEBUG
		//define for memory leak detect
		#define _CRTDBG_MAP_ALLOC
	#endif
#ifdef _WIN32_WCE
	#define CoInitialize(x)     CoInitializeEx(x, COINIT_MULTITHREADED)
#else
	#include <process.h>
#endif
	#include <shlwapi.h>
//assert mapping
//base type mapping
	#include "comm.h"
	typedef unsigned __int64 __uint64;
//base string mapping
	#include <afxmt.h>
	#include <afxtempl.h>
//base function mapping
//stl mapping
	#include <string>
	#include <vector>
	#include <map>
	//#pragma warning(disable :4996)	//hash_map �������ڷǱ�׼�����Ƽ�ʹ��
	//#include <hash_map>
	#include <set>
	#include <list>
	#include <algorithm>
	#include <stack>
	#include <queue>
	using namespace std;
//tchar mapping
	#include <tchar.h>
	typedef basic_string<TCHAR> tstring;
//cstring mapping
	//BSTR
	#include <oleauto.h>
	#include "CStringImpl.h"
#ifdef _WIN32_WCE
	static BOOL GetStringTypeExW(LCID lcid,DWORD dwInfoType,const wchar_t* pszSrc,int nLength,LPWORD pwCharType)
	{
		ASSERT(lcid==0);
		ASSERT(dwInfoType==CT_CTYPE1);
		ASSERT(nLength==1);
		if (lcid==0 && dwInfoType==CT_CTYPE1 && nLength==1 && pwCharType)
		{
			*pwCharType=0;
			const wchar_t ch=*pszSrc;
			if (ch>='A' && ch<='Z')
				*pwCharType|=C1_UPPER;
			if (ch>='a' && ch<='z')
				*pwCharType|=C1_LOWER;
			if (ch>='0' && ch<='9')
				*pwCharType|=C1_DIGIT;
			if (ch==' ')
				*pwCharType|=C1_SPACE;
			return TRUE;
		}
		return FALSE;
	}
	static BOOL GetStringTypeExA(LCID lcid,DWORD dwInfoType,const char* pszSrc,int nLength,LPWORD pwCharType)
	{
		ASSERT(lcid==0);
		ASSERT(dwInfoType==CT_CTYPE1);
		ASSERT(nLength==1);
		if (lcid==0 && dwInfoType==CT_CTYPE1 && nLength==1 && pwCharType)
		{
			*pwCharType=0;
			const char ch=*pszSrc;
			if (ch>='A' && ch<='Z')
				*pwCharType|=C1_UPPER;
			if (ch>='a' && ch<='z')
				*pwCharType|=C1_LOWER;
			if (ch>='0' && ch<='9')
				*pwCharType|=C1_DIGIT;
			if (ch==' ')
				*pwCharType|=C1_SPACE;
			return TRUE;
		}
		return FALSE;
	}
	static char *strlwr(char *src)
	{
		int len=strlen(src);
		for(int i=0;i<len;i++)
			src[i]=(char)tolower(src[i]);
		return src;
	}
	#include <stdlib.h>
	#include <math.h>
	static double _wtof(CString str)
	{
		CStringA stra(str);
		return atof(stra);
	}
	#define _tstof _wtof
	static time_t time( time_t *inTT )
	{
		SYSTEMTIME sysTimeStruct;
		FILETIME fTime;
		ULARGE_INTEGER int64time;
		time_t locTT = 0;
		if ( inTT == NULL )
			inTT = &locTT;
		GetSystemTime( &sysTimeStruct );
		if ( SystemTimeToFileTime( &sysTimeStruct, &fTime ) )
		{
			memcpy( &int64time, &fTime, sizeof( FILETIME ) );
			/* Subtract the value for 1970-01-01 00:00 (UTC) */
			int64time.QuadPart -= 0x19db1ded53e8000;
			/* Convert to seconds. */
			int64time.QuadPart /= 10000000;
			*inTT = (time_t)int64time.QuadPart;
		}
		return *inTT;
	}
	static int IsLeapYear(int year){return (0==year%4 && (0!=year%100 || 0==year%400));}
	static void abort(){ASSERT(FALSE);}
	static time_t mktime(struct tm* Date)
	{
		const int SecOfOneDay = 86400 ; // 24*60*60
		const short month[2][13]={
           365,31,28,31,30,31,30,31,31,30,31,30,31,
           366,31,29,31,30,31,30,31,31,30,31,30,31
		};
        long totalseconds = 0 ;
        int leapyear;
        int index ;
		// now index stands for the year
        for(index=1970; index< (Date->tm_year+1900); index++)
        {
			leapyear = IsLeapYear(index);
			totalseconds += (long)(month[leapyear][0] * SecOfOneDay);
        }
        leapyear = IsLeapYear(index);
		// now index stands for the month
        for(index=1 ; index<(Date->tm_mon+1) ; index++)
        {
          totalseconds += (long)(month[leapyear][index]*SecOfOneDay);
        }
		// day
        totalseconds += (long)((Date->tm_mday-1)*SecOfOneDay);
		// hour , minute ,second
        totalseconds += (long)(Date->tm_hour)*3600;
        totalseconds += (long)(Date->tm_min)*60;
        totalseconds += (long)Date->tm_sec;
        return (time_t)totalseconds;
	}
	//ce has ShellExecuteEx,but this imp more easy
	static HINSTANCE ShellExecute(HWND hwnd,const TCHAR *oper,const TCHAR *exe,const TCHAR *param,const TCHAR *path,int nShowCmd)
	{
		SHELLEXECUTEINFO ShellInfo;
		memset(&ShellInfo, 0, sizeof(ShellInfo));
		ShellInfo.cbSize = sizeof(ShellInfo);
		ShellInfo.hwnd = hwnd;
		ShellInfo.lpVerb = oper;
		ShellInfo.lpFile = exe;
		ShellInfo.nShow = nShowCmd;
		ShellInfo.lpDirectory=path;
		ShellInfo.lpParameters=param;
		ShellInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
		return (HINSTANCE)(ShellExecuteEx(&ShellInfo)?33:2);//an error value that is less than or equal to 32 otherwise,2 is ERROR_FILE_NOT_FOUND
	}
#endif
//mutli thread mapping
	#define WaitForSingleObjectEvent		WaitForSingleObject
//socket mapping
	#include <winsock2.h>
	#ifdef _WIN32_WCE
		#pragma comment(lib,"ws2.lib")
	#else
		#pragma comment(lib,"ws2_32.lib")
	#endif
	typedef SOCKET RAWSOCKET;
	#define IsWouldBlock(errorno)			(errorno==WSAEWOULDBLOCK)
//adptersinfo mapping
	#include <iptypes.h>
	#include <iphlpapi.h>
	#pragma comment(lib,"Iphlpapi.lib")
//http mapping
	#include <urlmon.h>
	#pragma comment(lib,"urlmon.lib")
#else
//linux os helper
//assert mapping
	#include <assert.h>
	#define ASSERT	assert
//base type mapping
	#include <ctype.h>
	#include <wctype.h>
	#include <stdint.h>
	#include <sys/types.h>
	typedef int INT_PTR;
	typedef long LONG_PTR;	//if use int,g++ in 64bits machine will cause 'loses precision' error
	typedef unsigned int UINT_PTR;
	typedef unsigned long ULONG_PTR;
	typedef unsigned long DWORD_PTR;
	typedef long LONG;
	typedef unsigned long ULONG;
	typedef uint32_t BOOL;
	typedef uint16_t WORD;
	typedef uint32_t DWORD;
	typedef uint32_t UINT;
	typedef int64_t __int64;
	typedef uint64_t __uint64;
	typedef int64_t __time64_t;
	typedef uint64_t ULONGLONG;
	typedef unsigned long HANDLE;
	typedef void * LPVOID;
	typedef uint32_t * LPDWORD;
	typedef char * LPSTR;
	typedef unsigned char BYTE;
	typedef unsigned char *LPBYTE;
	typedef unsigned char *PBYTE;
	typedef const char * LPCSTR;
	typedef const char * LPCTSTR;
	typedef wchar_t * LPWSTR;
	typedef const wchar_t * LPCWSTR;
	typedef LPWSTR BSTR;
	typedef wchar_t OLECHAR;
	typedef int32_t HRESULT;//��windows define��ͬ��������Ҫ�жϽ�32λ�������жϴ���Ϊ����
	typedef union _ULARGE_INTEGER {
		struct {
			DWORD LowPart;
			DWORD HighPart;
		} u;
		ULONGLONG QuadPart;
	} ULARGE_INTEGER,*PULARGE_INTEGER;
	#define SUCCEEDED(Status) ((HRESULT)(Status) >= 0)
	#define FAILED(Status) ((HRESULT)(Status)<0)
	#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
	#define FALSE 0
	#define TRUE 1
	#define MAX_PATH 260
	#define MIB_IF_TYPE_OTHER               1
	#define MIB_IF_TYPE_ETHERNET            6
	#define MIB_IF_TYPE_TOKENRING           9
	#define MIB_IF_TYPE_FDDI                15
	#define MIB_IF_TYPE_PPP                 23
	#define MIB_IF_TYPE_LOOPBACK            24
	#define MIB_IF_TYPE_SLIP                28
	#define S_OK							((HRESULT)0x00000000L)
	#define S_FALSE							((HRESULT)0x00000001L)
	#define E_FAIL							((HRESULT)0x80004005L)
	#define E_ABORT                         ((HRESULT)0x80004004L)
	#define STG_E_WRITEFAULT				((HRESULT)0x8003001DL)
//base string mapping
	#include <string.h>
	#include <strings.h>
	#include <wchar.h>
	#include <stdarg.h>
	static char *strlwr(char *src)
	{
		int len=strlen(src);
		for(int i=0;i<len;i++)
			src[i]=(char)tolower(src[i]);
		return src;
	}
	static wchar_t *wcslwr(wchar_t *src)
	{
		int len=wcslen(src);
		for(int i=0;i<len;i++)
			src[i]=(wchar_t)towlower(src[i]);
		return src;
	}
	static char *strupr(char *src)
	{
		int len=strlen(src);
		for(int i=0;i<len;i++)
			src[i]=(char)toupper(src[i]);
		return src;
	}
	static wchar_t *wcsupr(wchar_t *src)
	{
		int len=wcslen(src);
		for(int i=0;i<len;i++)
			src[i]=(wchar_t)towupper(src[i]);
		return src;
	}
	static int vswprintf( wchar_t *buffer, const wchar_t *format, va_list argptr)
	{
		//��������buffer����Ĵ�С,������λ��?ʹ��CString��DEFAULT_ALLOC_SIZE
		return ::vswprintf(buffer,256/*DEFAULT_ALLOC_SIZE*/,format,argptr);
	}
	#define stricmp							strcasecmp
	#define strnicmp						strncasecmp
	#define wcsicmp							wcscasecmp
	#define wcsnicmp						wcsncasecmp
	static long _wtol(const wchar_t *src)
	{
		//not imp
		ASSERT(FALSE);
		return 0;
	}
	static double _wtof(const wchar_t *src)
	{
		//not imp
		ASSERT(FALSE);
		return 0;
	}
	static BSTR SysAllocString(const OLECHAR *src)
	{
		//Ϊ�˺�SysAllocStringLen���ݣ�����wcsdup
		wchar_t *ch=new wchar_t[wcslen(src)+1];
		wcscpy(ch,src);
		return ch;
	}
	static void SysFreeString(BSTR org)
	{
		delete [] org;
	}
	static BSTR SysAllocStringLen(const OLECHAR *src,unsigned int len)
	{
		wchar_t *ch=new wchar_t[len+1];
		wcsncpy(ch,src,len);
		ch[len]='\0';
		return ch;
	}
	static BSTR SysReAllocStringLen(BSTR *org,const OLECHAR *src,unsigned int len)
	{
		SysFreeString(*org);
		*org=SysAllocStringLen(src,len);
		return *org;
	}
	#define CP_ACP                    0           // default to ANSI code page
	#define CP_OEMCP                  1           // default to OEM  code page
	#define CP_MACCP                  2           // default to MAC  code page
	#define CP_THREAD_ACP             3           // current thread's ANSI code page
	#define CP_SYMBOL                 42          // SYMBOL translations
	#define CP_UTF7                   65000       // UTF-7 translation
	#define CP_UTF8                   65001       // UTF-8 translation
	static int MultiByteToWideChar(UINT CodePage,DWORD dwFlags,LPCSTR lpMultiByteStr,int cbMultiByte,LPWSTR lpWideCharStr,int cchWideChar)
	{
		//not imp
		ASSERT(FALSE);
		return 0;
	}
	static int WideCharToMultiByte(UINT CodePage,DWORD dwFlags,LPCWSTR lpWideCharStr,int cchWideChar,LPSTR lpMultiByteStr,int cbMultiByte,LPCSTR lpDefaultChar,BOOL *lpUsedDefaultChar)
	{
		//not imp
		ASSERT(FALSE);
		return 0;
	}
//base function mapping
	#include <errno.h>
	#include <unistd.h>
	#include <sys/param.h>
	#define _vsnprintf vsnprintf
	static uint32_t GetLastError(){return errno;}
	#define SetProcessWorkingSetSize
	#include <sys/times.h>
	#include <sys/time.h>
	#include <time.h>
	#include<sys/stat.h>
	#include <dirent.h>
	#include <sys/statvfs.h>
	#define Sleep(x)						usleep((x)*1000)
	static uint32_t GetTickCount()
	{
		static long int g_fristsec=0;
  		struct timeval tv;
        gettimeofday(&tv, NULL);
		if (!g_fristsec)
			g_fristsec=tv.tv_sec-1000;
        return (uint32_t)((tv.tv_sec-g_fristsec)*1000 + tv.tv_usec/1000);
		//�������׼
/* 		tms tm;
  		return times(&tm)*10;*/
	}
	typedef struct _SYSTEMTIME
	{
		WORD wYear;
		WORD wMonth;
		WORD wDayOfWeek;
		WORD wDay;
		WORD wHour;
		WORD wMinute;
		WORD wSecond;
		WORD wMilliseconds;
	}SYSTEMTIME;
	static void GetLocalTime(SYSTEMTIME *ti)
	{
		if (!ti) return;
		memset(ti,0,sizeof(SYSTEMTIME));
		struct timeval tv;
		if (gettimeofday(&tv,NULL)==0)
		{
			ti->wMilliseconds=tv.tv_usec/1000;
		}
		time_t tim=time(NULL);
		tm *t=localtime(&tim);
		if (t)
		{
			ti->wYear=t->tm_year+1900;
			ti->wMonth=t->tm_mon+1;
			ti->wDay=t->tm_mday;
			ti->wDayOfWeek=t->tm_wday;
			ti->wHour=t->tm_hour;
			ti->wMinute=t->tm_min;
			ti->wSecond=t->tm_sec;
		}
	}
	static void GetSystemTime(SYSTEMTIME *ti)
	{
		if (!ti) return;
		memset(ti,0,sizeof(SYSTEMTIME));
		struct timeval tv;
		if (gettimeofday(&tv,NULL)==0)
		{
			ti->wMilliseconds=tv.tv_usec/1000;
		}
		time_t tim=time(NULL);
		tm *t=gmtime(&tim);
		if (t)
		{
			ti->wYear=t->tm_year+1900;
			ti->wMonth=t->tm_mon+1;
			ti->wDay=t->tm_mday;
			ti->wDayOfWeek=t->tm_wday;
			ti->wHour=t->tm_hour;
			ti->wMinute=t->tm_min;
			ti->wSecond=t->tm_sec;
		}
	}
	#define OutputDebugString(x)			fputs(x,stderr)
	#define OutputDebugStringA(x)			fputs(x,stderr)
//stl mapping
	#include <string>
	#include <vector>
	#include <map>
	//#include <ext/hash_map>
	#include <set>
	#include <list>
	#include <algorithm>
	#include <stack>
	#include <queue>
	using namespace std;
	//using namespace __gnu_cxx;//for hash_map
	typedef string tstring;
//tchar mapping
	typedef char TCHAR;
	typedef TCHAR * LPTSTR;
	typedef const TCHAR * LPCTSTR;
	#define _T(x)	x
	#define _vsntprintf vsnprintf
	#define _tprintf printf
	#define _stprintf sprintf
	#define _sntprintf snprintf
	#define _tcstol strtol
	#define _tcscpy strcpy
	#define _tcslen	strlen
	#define _tcscat strcat
	#define _tcscmp strcmp
	#define _tcsicmp strcasecmp
	#define _tcsstr strstr
	#define _ttoi atoi
	#define _tstoi atoi
	#define _ttoi64 atoll
	#define _wtoi atoi
	#define _ttol atol
	#define _tstol atol
	#define _ttof atof
	#define _tstof atof
	typedef basic_string<TCHAR> tstring;
//cstring mapping
	#include "CStringImpl.h"
	typedef CString CStringA;
	typedef CString CStringW;
//mutli thread mapping
	#include <signal.h>
	#include <pthread.h>
	#define DeleteCriticalSection			pthread_mutex_destroy
	#define EnterCriticalSection			pthread_mutex_lock
	#define LeaveCriticalSection			pthread_mutex_unlock
	static BOOL TryEnterCriticalSection(pthread_mutex_t *mtx)
	{
		return pthread_mutex_trylock(mtx)==0;
	}
	#define CRITICAL_SECTION				pthread_mutex_t
	//why gettid not actived?
	//_syscall0(pid_t, gettid)
	//#define GetCurrentThreadId gettid
	static DWORD GetCurrentProcessId()
	{
		return getpid();
	}
	static CString GetProcPath()
	{
		CString str;
		str.Format(_T("/proc/%u/cwd"),getpid());
		char buf[1024];
		int count=readlink(str,buf,1024);
		if (count>0 && count<1024)
		{
			buf[count]='\0';
			str=buf;
		}
		return str;
	}
	static CString GetProcExe()
	{
		CString str;
		str.Format(_T("/proc/%u/exe"),getpid());
		char buf[1024];
		int count=readlink(str,buf,1024);
		if (count>0 && count<1024)
		{
			buf[count]='\0';
			str=buf;
		}
		return str;
	}
	#define SW_HIDE             0
	#define SW_SHOWNORMAL       1
	#define SW_MAXIMIZE         3
	#define SW_SHOWNOACTIVATE   4
	#define SW_SHOW             5
	#define SW_MINIMIZE         6
	#define SW_RESTORE          9
	#define SW_SHOWDEFAULT      10
	#define HINSTANCE HANDLE
	#define HWND HANDLE
	static HINSTANCE ShellExecute(HWND hwnd,const TCHAR *oper,const TCHAR *exe,const TCHAR *param,const TCHAR *path,int nShowCmd)
	{
		if (path) chdir(path);
		ASSERT(oper==NULL || _tcsicmp(oper,_T("open"))==0);
		ASSERT(exe!=NULL);
		if (param)
		{
			TCHAR buf[4096];
			_tcscpy(buf,exe);
			_tcscat(buf,_T(" "));
			_tcscat(buf,param);
			exe=buf;
		}
		return system(exe)==-1?2:33;//an error value that is less than or equal to 32 otherwise,2 is ERROR_FILE_NOT_FOUND
	}
	#define MB_OK                       0x00000000L
	#define MB_OKCANCEL                 0x00000001L
	#define MB_YESNOCANCEL              0x00000003L
	#define MB_YESNO                    0x00000004L
	#define MB_ICONHAND                 0x00000010L
	#define MB_ICONQUESTION             0x00000020L
	#define MB_ICONEXCLAMATION          0x00000030L
	#define MB_ICONASTERISK             0x00000040L
	#define MB_USERICON                 0x00000080L
	#define MB_ICONWARNING              MB_ICONEXCLAMATION
	#define MB_ICONERROR                MB_ICONHAND
	#define MB_ICONINFORMATION          MB_ICONASTERISK
	#define MB_ICONSTOP                 MB_ICONHAND
	#define MB_TOPMOST                  0x00040000L
	#define IDOK                1
	#define IDCANCEL            2
	#define IDABORT             3
	#define IDRETRY             4
	#define IDIGNORE            5
	#define IDYES               6
	#define IDNO                7
	static int MessageBox(HWND hWnd,LPCTSTR cnt,LPCTSTR title,int nType)
	{
		//laterme,not imp
		return 0;
	}
	//ע��fopenӦ�����ã�_tfopen������·��ת��
	static FILE* _tfopen(CString file,CString mode)
	{
		file.Replace(_T("\\"),_T("/"));
		return fopen(file,mode);
	}
	//��õ����������ĵ�ַ
	#define GetCurrentThreadId				pthread_self
	#define WAIT_OBJECT_0					0x0
	#define WAIT_FAILED						((DWORD)0xFFFFFFFF)
	#define WAIT_TIMEOUT					0x102
	#define INFINITE						0xFFFFFFFF
	//event
	//event imp is only for autoreset event
	//WaitForSingleObject Event imp
	static DWORD WaitForSingleObjectEvent(volatile HANDLE &Event,int nMS)
	{
		if (Event==0) return WAIT_FAILED;
		int nSec=nMS;
		while(nSec>0)
		{
			if (Event==2)
			{
				Event=1;
				return WAIT_OBJECT_0;
			}
			int nS=(nSec>10)?10:nSec;
			usleep(nS*1000);
			if (nMS!=INFINITE) nSec-=nS;
		}
		return WAIT_TIMEOUT;
	}
	#define NOSINGAL						1
	#define SINGAL							2
	static bool SetEvent(volatile HANDLE &Event){Event=SINGAL;return TRUE;}
//socket mapping
	#include <sys/socket.h>
	#include <sys/ioctl.h>
	#include <arpa/inet.h>
	#include <netdb.h>
	#include <sys/epoll.h>
	typedef struct sockaddr SOCKADDR,*LPSOCKADDR;
	typedef struct in_addr IN_ADDR,*LPIN_ADDR;
	typedef int SOCKET;
	typedef SOCKET RAWSOCKET;
	#define INVALID_SOCKET					((SOCKET)(~0))
	#define SOCKET_ERROR					(-1)
	static uint32_t WSAGetLastError(){return errno;}
#if (BUILDMODE==2 && defined(_MIPS))
	#define IsWouldBlock(errorno)			(errorno==EWOULDBLOCK || errorno==EINTR || errorno==EAGAIN || errorno==2)
#else
	#define IsWouldBlock(errorno)			(errorno==EWOULDBLOCK || errorno==EINTR || errorno==EAGAIN)
#endif
	#define ioctlsocket						ioctl
	#define closesocket						close
	//#include "CINet.h"
//com mapping
	static void CoInitialize(void *p){}
	static void CoUninitialize(){}
//base imp
	//#include "CTime.h"
	//#include "CFile.h"
#endif

#include "oemfun.h"

